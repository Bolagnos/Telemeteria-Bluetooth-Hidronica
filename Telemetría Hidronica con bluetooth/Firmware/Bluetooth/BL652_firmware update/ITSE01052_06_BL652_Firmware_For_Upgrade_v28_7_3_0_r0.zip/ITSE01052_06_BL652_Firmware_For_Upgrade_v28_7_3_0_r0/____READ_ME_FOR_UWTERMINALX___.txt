(c) Laird 2017

=============
UwTerminalX
=============
The latest version of UwTerminalX is available at GitHub, so launch
UwTerminalX Releases by right-clicking it, and selecting 'Open'




  
