(c) Laird 2017

This readme file explains the process of cloning the flash file and data system
so that a single hex file can be created for a production process which takes 
roughly 6 seconds to download

----------------------------------------------------------------------------------
IMPORTANT NOTE:
IT IS VERY IMPORTANT THAT CLONING IS DONE TO MODULES WITH THE SAME 
FIRMWARE VERSION.
IF FIRMWARE VERSION DIFFER, THEN THE SMARTBASIC APPLICATIONS WILL NOT RUN
----------------------------------------------------------------------------------

( 1) Ensure that the firmware in the golden module/devkit is the correct one
( 2) Check using AT I 3 step (1)
( 3) Clear the file system by sending the command 
     AT&F*
( 4) Using UwTerminalX, download all the smartBASIC apps you need for your system.
     (as a test you can download the 'hw.hello.world.sb' app included)
     ==========================================================================
     >>>> The xcompiler for this version is supplied in this package and   <<<<
     >>>> so copy it to the folder containing UwTerminal and/or the folder <<<<
     >>>> where you keep the applications                                  <<<<
     >>>>                                                                  <<<<
     >>>> Note you can tell what firmware a x-compiler corresponds to by   <<<<
     >>>> running the exe with the command line argument /I                <<<<
     >>>>                                                                  <<<<
     ==========================================================================
( 5) Set appropiate config keys using AT+CFG nn mmm     
( 6) Using the command AT+DIR confirm that you see the apps you expect
( 7) For sanity check, run all apps downloaded and confirm they work as expected
( 8) Run the batch file '_CaptureAndGenFFDS.bat' which will result in two new files
     as follows:-
     <BL652_FFDS.hex>  and  <BL652_FFDS.uwf>
( 9) Check that the 2 new files exists
(10) To check that it will work we need to clear the flash file & Data system.
     To do that submit the command AT&F*      
(11) Using the command AT+DIR confirm that the file system is empty
(12) Now download the flash file system & data hex
     To download using JLINK, use batchfile '_DownloadxFFDS.bat'
     To download over UART,   use batchfile '_DownloadxFfdsUart.bat'
(13) Reset or power cycle the module
(14) Using the command AT+DIR confirm that you see the apps you expect
     (if you just had the hello world app, then you will see just a file called 'hw')
(15) If appropriate check that config keys that were modified now return the
     values set in an earlier step by issues the AT+CFG nn ? commands


  
++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
Acknowledgements:
The utility Hex2Bin by Jacques Pelletier & Contributors is used to convert hex
files to binary. It is released under a BSD Licence and was downloaded from
http://sourceforge.net/projects/hex2bin/
++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
