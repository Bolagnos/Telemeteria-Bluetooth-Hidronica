###########################################################################

If you are connected via uart, run _DownloadFirmwareUart.bat

If you are connected via jtag, run _DownloadFirmwareJlink.bat

###########################################################################

----------------------------------------------------------------------------
After downloading the new firmware, validate it as follows:-

   * Start UwTerminal
   * Set comms parameters as 115200, n, 8, 1 with CTS/RTS handshaking
   * type AT and check you get a 00 response
   * type AT i 3 and check you get a version number as per the version
     number embedded in the hex or uwf filename
   * In UwTerminal right-click and select "XCompile+Load"
   * Select the file "hw.hello.world.sb"
     and you MUST see many lines starting with AT+FWRH and then finally a 
     line AT+FCL
   * type 
       at+dir
     and you should see a line with '06    hw'
   * type
       at+run "hw" 
   * Check that you see "Hello World" and then a "00"
   * type
       at i 4
     and you will see the mac address of the module. 
     
     It must NOT have'C0FFEE' in the response string. 
     If it does have 'C0FFEE' then the module does not have a licence and
     you will need to contact Laird Support and give them the response to
     the command   AT I 14
     
